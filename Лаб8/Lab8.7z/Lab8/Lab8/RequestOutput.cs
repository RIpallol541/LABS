﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab8
{

    internal class RequestOutput
    {
        private OleDbConnection Connection = null;
        
        public DataSet request(string req)
        {
            Connection = new OleDbConnection(ConfigurationManager.ConnectionStrings["myBd"].ConnectionString);
            Connection.Open();
            try
            {
                OleDbDataAdapter adapter = new OleDbDataAdapter(req, Connection);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                Connection.Close();
                return ds;
            }
            catch (Exception ex)
            {
                DataSet ds = new DataSet();
                DataTable customers = ds.Tables.Add("Error");
                customers.Columns.Add("Error");
                customers.Rows.Add("Запрос не корректен");
                return ds;
            }
            
        }
           
    }
}
